"use strict";
console.log('Extension Klassly Image Downloader chargée (mode scan via popup uniquement)');
