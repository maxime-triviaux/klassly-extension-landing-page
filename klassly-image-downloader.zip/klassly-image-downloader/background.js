"use strict";
const VALID_IMAGE_EXTENSIONS = [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'
];
function getFileExtension(url) {
    try {
        const pathname = new URL(url).pathname;
        const extension = pathname.split('.').pop()?.toLowerCase();
        if (extension && VALID_IMAGE_EXTENSIONS.includes(extension)) {
            return `.${extension}`;
        }
        return '.jpg';
    }
    catch (error) {
        console.warn('Impossible de déterminer l\'extension du fichier:', error);
        return '.jpg';
    }
}
async function downloadImage(url, filename) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const extension = getFileExtension(url);
    const finalFilename = `klassly-images/${filename}_${timestamp}${extension}`;
    const downloadId = await chrome.downloads.download({
        url: url,
        filename: finalFilename,
        conflictAction: 'uniquify'
    });
    console.log(`Image téléchargée avec l'ID: ${downloadId}, fichier: ${finalFilename}`);
}
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
    if (request.action === 'download') {
        downloadImage(request.url, request.filename)
            .then(() => {
            sendResponse({ success: true });
        })
            .catch((error) => {
            console.error('Erreur lors du téléchargement:', error);
            sendResponse({
                success: false,
                error: error.message
            });
        });
        return true;
    }
    return false;
});
chrome.runtime.onInstalled.addListener((details) => {
    const reason = details.reason;
    switch (reason) {
        case 'install':
            console.log('Extension Klassly Image Downloader installée');
            break;
        case 'update':
            console.log('Extension Klassly Image Downloader mise à jour');
            break;
        default:
            console.log(`Extension mise à jour: ${reason}`);
    }
});
chrome.downloads.onChanged.addListener((downloadDelta) => {
    if (downloadDelta.state?.current === 'complete') {
        console.log('Téléchargement terminé:', downloadDelta.id);
    }
    else if (downloadDelta.state?.current === 'interrupted') {
        console.error('Téléchargement interrompu:', downloadDelta.id);
    }
});
