"use strict";
console.log('Extension Klassly Image Downloader chargée');
function createDownloadButton() {
    const button = document.createElement('button');
    button.id = 'klassly-download-btn';
    button.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7,10 12,15 17,10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        Télécharger les images
    `;
    button.title = 'Télécharger toutes les images de la page';
    button.addEventListener('click', handleDownloadClick);
    return button;
}
function handleDownloadClick() {
    console.log('Bouton de téléchargement cliqué');
    const images = document.querySelectorAll('img');
    let imageCount = 0;
    images.forEach((img, index) => {
        if (img.src && !img.src.startsWith('data:')) {
            imageCount++;
            sendDownloadMessage(img.src, `image_${index + 1}`);
        }
    });
    if (imageCount === 0) {
        alert('Aucune image trouvée sur cette page');
    }
    else {
        showNotification(`Téléchargement de ${imageCount} image(s) en cours...`, 'success');
    }
}
function sendDownloadMessage(url, filename) {
    try {
        const message = {
            action: 'download',
            url: url,
            filename: filename
        };
        chrome.runtime.sendMessage(message);
    }
    catch (error) {
        console.error('Erreur lors du téléchargement:', error);
        showNotification('Erreur lors du téléchargement', 'error');
    }
}
function showNotification(message, type = 'info') {
    const existingNotification = document.getElementById('klassly-notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    const notification = document.createElement('div');
    notification.id = 'klassly-notification';
    notification.textContent = message;
    const colors = {
        success: '#4CAF50',
        error: '#f44336',
        info: '#2196F3'
    };
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${colors[type]};
        color: white;
        padding: 12px 20px;
        border-radius: 4px;
        z-index: 10001;
        font-family: Arial, sans-serif;
        font-size: 14px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        animation: slideInFromTop 0.3s ease-out;
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}
function injectButton() {
    if (document.getElementById('klassly-download-btn')) {
        return;
    }
    const button = createDownloadButton();
    const container = document.createElement('div');
    container.id = 'klassly-button-container';
    container.appendChild(button);
    document.body.appendChild(container);
}
function shouldShowButton() {
    const allowedDomains = ['klass.ly'];
    return allowedDomains.some((domain) => window.location.hostname.includes(domain));
}
function init() {
    if (shouldShowButton()) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', injectButton);
        }
        else {
            injectButton();
        }
    }
}
init();
