"use strict";
function getPopupElements() {
    const downloadBtn = document.getElementById('downloadBtn');
    const status = document.getElementById('status');
    if (!downloadBtn || !status) {
        throw new Error('Éléments DOM requis non trouvés');
    }
    return { downloadBtn, status };
}
function isValidWebUrl(url) {
    return url.startsWith('http://') || url.startsWith('https://');
}
function isChromeSystemPage(url) {
    return url.startsWith('chrome://') || url.startsWith('chrome-extension://');
}
function triggerDownload() {
    async function downloadImageViaFetch(imageUrl, filename = 'image') {
        try {
            const response = await fetch(imageUrl);
            const blob = await response.blob();
            const blobUrl = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = blobUrl;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(blobUrl);
        }
        catch (error) {
            console.error('Erreur de téléchargement:', error);
            downloadImage(imageUrl, filename);
        }
    }
    function getFilenameFromUrl(url) {
        const urlParts = url.split('/');
        const filename = urlParts[urlParts.length - 1];
        return filename || 'image';
    }
    const thumbs = document.querySelectorAll('.kr-media-grid-item__img');
    thumbs.forEach((thumb, index) => {
        const container = thumb.parentElement?.parentElement;
        if (!container) {
            console.warn('Container non trouvé pour l\'élément thumb');
            return;
        }
        const downloadButton = document.createElement('div');
        downloadButton.className = 'kr-icon-button kr-icon-button__white kr-media-grid-item__tag-child';
        downloadButton.style.cssText = '--size: 32px; margin-top: 40px;';
        const icon = document.createElement('i');
        icon.className = 'kr-icon icon icon-download';
        downloadButton.appendChild(icon);
        downloadButton.addEventListener('click', async function (event) {
            event.stopPropagation();
            event.preventDefault();
            event.stopImmediatePropagation();
            const bgImage = window.getComputedStyle(thumb).backgroundImage;
            const urlMatch = bgImage.match(/url\(['"]?(.*?)['"]?\)/);
            if (urlMatch && urlMatch[1]) {
                let imageUrl = urlMatch[1];
                const cleanUrl = imageUrl.replace('.thumb', '');
                console.log('-- Maxime TEST');
                console.log('URL originale:', imageUrl);
                console.log('URL nettoyée:', cleanUrl);
                const filename = getFilenameFromUrl(cleanUrl) || `image_${index + 1}`;
                console.log('🚀 Téléchargement en cours...', cleanUrl);
                await downloadImageViaFetch(cleanUrl, filename);
            }
            else {
                console.log('-- Maxime TEST - Aucune background-image trouvée');
            }
            return false;
        }, true);
        container.appendChild(downloadButton);
    });
}
function updateButtonState(button, status, isLoading) {
    if (isLoading) {
        button.innerHTML = `<svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
            </svg>
            Scan en cours...`;
        button.disabled = true;
        status.innerHTML = 'Scan en cours...';
    }
    else {
        button.innerHTML = `<svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="22,12 18,12 15,21 9,3 6,12 2,12"/>
            </svg> Scanner la page`;
        button.disabled = false;
        status.innerHTML = 'Scan terminé !';
    }
}
function handleDownload(elements) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.id || !tab.url) {
            elements.status.textContent = 'Impossible d\'accéder à l\'onglet actuel';
            return;
        }
        if (isValidWebUrl(tab.url)) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: triggerDownload
            }).then(() => {
                updateButtonState(elements.downloadBtn, elements.status, true);
                setTimeout(() => {
                    updateButtonState(elements.downloadBtn, elements.status, false);
                }, 1000);
            }).catch((error) => {
                console.error('Erreur lors de l\'injection du script:', error);
                elements.status.textContent = 'Erreur lors du téléchargement';
                elements.downloadBtn.disabled = false;
            });
        }
        else {
            elements.status.textContent = 'Cette page ne supporte pas le téléchargement';
        }
    });
}
function checkInitialStatus(elements) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.url) {
            elements.status.textContent = 'Impossible d\'accéder à l\'onglet actuel';
            elements.downloadBtn.disabled = true;
            return;
        }
        if (isChromeSystemPage(tab.url)) {
            elements.status.textContent = 'Non disponible sur cette page';
            elements.downloadBtn.disabled = true;
        }
        else if (!isValidWebUrl(tab.url)) {
            elements.status.textContent = 'Page non supportée';
            elements.downloadBtn.disabled = true;
        }
    });
}
document.addEventListener('DOMContentLoaded', () => {
    try {
        const elements = getPopupElements();
        elements.downloadBtn.addEventListener('click', () => {
            handleDownload(elements);
        });
        checkInitialStatus(elements);
    }
    catch (error) {
        console.error('Erreur lors de l\'initialisation du popup:', error);
    }
});
